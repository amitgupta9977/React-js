import React from "react";
import ReactDOM from "react-dom/client";
import News from "./component/News";

ReactDOM.createRoot(document.getElementById("root")).render(<News />);
